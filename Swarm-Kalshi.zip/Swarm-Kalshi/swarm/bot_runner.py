"""
bot_runner.py
=============

Runs individual bot instances as separate processes within the swarm.

Each bot runner:
- Loads the merged config (swarm defaults + bot-specific overrides)
- Initializes all v2 + v3 modules
- Runs the main trading loop
- Reports status back to the swarm coordinator via shared state files
"""

from __future__ import annotations

import json
import logging
import logging.handlers
import os
import signal
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

import yaml

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from kalshi_agent.kalshi_client import KalshiClient, KalshiAPIError
from kalshi_agent.market_scanner import MarketScanner
from kalshi_agent.analysis_engine import AnalysisEngine
from kalshi_agent.human_behavior import HumanBehavior
from kalshi_agent.risk_manager import RiskManager
from kalshi_agent.learning_engine import LearningEngine
from kalshi_agent.dashboard import Dashboard
from kalshi_agent.backtester import Backtester
from kalshi_agent.external_signals import ExternalSignals
from kalshi_agent.prior_knowledge import PriorKnowledge
from kalshi_agent.llm_advisor import LLMAdvisor

logger = logging.getLogger("kalshi_agent")


class BotRunner:
    """
    Runs a single specialist bot instance.

    Parameters
    ----------
    bot_name : str
        The bot identifier (e.g., "sentinel", "oracle").
    swarm_config_path : str
        Path to the global swarm config.
    bot_config_path : str
        Path to the bot-specific config overrides.
    project_root : str
        Root directory of the project (for resolving relative paths).
    """

    def __init__(
        self,
        bot_name: str,
        swarm_config_path: str,
        bot_config_path: str,
        project_root: str = ".",
    ):
        self.bot_name = bot_name
        self.project_root = Path(project_root)
        self.cfg = self._load_merged_config(swarm_config_path, bot_config_path)
        self._setup_logging()
        self._running = True
        self._paused = False

        # Status file for coordinator communication
        self._status_file = self.project_root / "data" / f"{bot_name}_status.json"
        self._status_file.parent.mkdir(parents=True, exist_ok=True)

        # Initialize all modules
        api_cfg = self.cfg["api"]
        
        # Handle private key path - support both absolute and relative paths
        key_path = Path(api_cfg["private_key_path"])
        logger.info(f"[DEBUG] Raw key path from config: {api_cfg['private_key_path']}")
        logger.info(f"[DEBUG] Is absolute: {key_path.is_absolute()}")
        if not key_path.is_absolute():
            key_path = self.project_root / key_path
        logger.info(f"[DEBUG] Final key path: {key_path}")
        logger.info(f"[DEBUG] Key file exists: {key_path.exists()}")
        
        self.client = KalshiClient(
            api_key_id=api_cfg["key_id"],
            private_key_path=str(key_path),
            base_url=api_cfg["base_url"],
            demo_mode=api_cfg.get("demo_mode", True),
        )

        trading_cfg = self.cfg.get("trading", {})
        risk_cfg = {**trading_cfg, **self.cfg.get("risk", {})}

        self.scanner = MarketScanner(self.client, trading_cfg)
        self.learning = LearningEngine(self.cfg.get("learning", {}))

        # Initialize prior knowledge
        specialist = self.cfg.get("prior_knowledge", {}).get(
            "specialist",
            self.cfg.get("bot", {}).get("specialist", "general"),
        )
        self.priors = PriorKnowledge(
            specialist=specialist,
            config=self.cfg.get("prior_knowledge", {}),
        )

        # Use prior-seeded weights as starting point
        initial_weights = self.priors.get_initial_weights()

        # v3 modules (must be initialized before AnalysisEngine)
        self.external_signals = ExternalSignals(
            client=self.client,
            config=self.cfg.get("external_signals", {}),
        )

        self.llm_advisor = LLMAdvisor(
            config=self.cfg.get("llm_advisor", {}),
        )

        self.analysis = AnalysisEngine(
            trading_cfg,
            weight_overrides=initial_weights,
            learning_engine=self.learning,
            external_signals=self.external_signals,
            llm_advisor=self.llm_advisor,
        )

        self.behavior = HumanBehavior(
            self.cfg.get("human_behavior", {}),
            state_file=str(self.project_root / "data" / f"{bot_name}_behavior_state.json"),
        )
        self.risk = RiskManager(risk_cfg)
        self.dashboard = Dashboard(self.learning)

        self.backtester = Backtester(
            client=self.client,
            scanner=self.scanner,
            analysis=self.analysis,
            learning=self.learning,
            config=self.cfg.get("backtester", {}),
        )

        # Category and keyword filters
        self._category_filters = set(
            c.lower() for c in self.cfg.get("category_filters", [])
        )
        self._excluded_categories = set(
            c.lower() for c in self.cfg.get("excluded_categories", [])
        )
        self._category_keywords = [
            k.lower() for k in self.cfg.get("category_keywords", [])
        ]
        self._series_filters = set(
            s.upper() for s in self.cfg.get("series_filters", [])
        )

        self._pending_trades: Dict[str, int] = {}
        self._trade_count = 0
        self._session_start = None
        self._last_backtest_date: Optional[datetime] = None
        
        # FIX: Cache last known good balance to prevent $0 displays
        self._last_known_balance: int = 0
        self._last_balance_update: Optional[datetime] = None

        signal.signal(signal.SIGINT, self._handle_signal)
        signal.signal(signal.SIGTERM, self._handle_signal)

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def _load_merged_config(
        self, swarm_path: str, bot_path: str
    ) -> Dict[str, Any]:
        """Load and merge swarm config with bot-specific overrides."""
        with open(swarm_path) as fh:
            base = yaml.safe_load(fh) or {}

        with open(bot_path) as fh:
            overrides = yaml.safe_load(fh) or {}

        return self._deep_merge(base, overrides)

    @staticmethod
    def _deep_merge(base: Dict, override: Dict) -> Dict:
        """Recursively merge override into base."""
        result = dict(base)
        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = BotRunner._deep_merge(result[key], value)
            else:
                result[key] = value
        return result

    def _setup_logging(self) -> None:
        log_cfg = self.cfg.get("logging", {})
        level = getattr(logging, log_cfg.get("level", "INFO").upper(), logging.INFO)
        fmt = logging.Formatter(
            f"%(asctime)s | %(levelname)-8s | {self.bot_name} | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        console = logging.StreamHandler(sys.stdout)
        console.setFormatter(fmt)
        logger.addHandler(console)

        log_file = log_cfg.get("file", f"logs/{self.bot_name}.log")
        log_path = self.project_root / log_file
        log_path.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.handlers.RotatingFileHandler(
            str(log_path),
            maxBytes=log_cfg.get("max_bytes", 10_485_760),
            backupCount=log_cfg.get("backup_count", 5),
        )
        file_handler.setFormatter(fmt)
        logger.addHandler(file_handler)
        logger.setLevel(level)

    def _handle_signal(self, signum, frame):
        logger.info("Received signal %d -- shutting down gracefully.", signum)
        self._running = False

    # ------------------------------------------------------------------
    # Market filtering
    # ------------------------------------------------------------------

    def _matches_specialist(self, market: Dict[str, Any]) -> bool:
        """Check if a market matches this bot's specialist filters."""
        # If no filters, accept everything (Vanguard behavior)
        if not self._category_filters and not self._series_filters:
            # But check exclusions
            category = (market.get("category") or "").lower()
            if category in self._excluded_categories:
                return False
            return True

        ticker = market.get("ticker", "")
        category = (market.get("category") or "").lower()
        title = (market.get("title") or "").lower()
        series_ticker = ticker.split("-")[0].upper() if "-" in ticker else ticker.upper()

        # Series match
        if self._series_filters and series_ticker in self._series_filters:
            return True

        # Category match
        if category and category in self._category_filters:
            return True

        # Partial category match
        for cat_filter in self._category_filters:
            if cat_filter in category or category in cat_filter:
                return True

        # Keyword match
        if self._category_keywords:
            for kw in self._category_keywords:
                if kw in title:
                    return True

        return False

    def _should_run_weekly_backtest(self) -> bool:
        """Return True if it's been 7+ days since the last backtest run."""
        if self._last_backtest_date is None:
            return False
        from datetime import timedelta
        return (datetime.now(timezone.utc) - self._last_backtest_date) >= timedelta(days=7)

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def run(self) -> None:
        bot_cfg = self.cfg.get("bot", {})
        display_name = bot_cfg.get("display_name", self.bot_name)
        description = bot_cfg.get("description", "")

        logger.info("=" * 60)
        logger.info("Bot '%s' (%s) starting up.", display_name, self.bot_name)
        logger.info("Specialist: %s", bot_cfg.get("specialist", "general"))
        logger.info("Description: %s", description)
        logger.info("Base URL: %s", self.cfg["api"]["base_url"])
        logger.info("=" * 60)

        # Auto-run backtester if DB is empty
        if self.backtester.should_auto_run():
            logger.info("Empty database detected. Running initial backtester...")
            bt_result = self.backtester.run()
            logger.info("Backtester result: %s", bt_result)
            self._last_backtest_date = datetime.now(timezone.utc)

        self._session_start = datetime.now(timezone.utc)

        # Fetch real balance immediately so the first status write isn't $0
        try:
            self._refresh_state()
        except Exception:
            pass

        self._write_status("running")

        while self._running:
            try:
                if self._paused:
                    self._write_status("paused")
                    time.sleep(5)
                    continue

                # Weekly re-backtest against last 90 days of settled markets
                if self._should_run_weekly_backtest():
                    logger.info("Running weekly backtest recalibration...")
                    bt_result = self.backtester.run()
                    logger.info("Weekly backtest result: %s", bt_result)
                    self._last_backtest_date = datetime.now(timezone.utc)

                self._run_cycle()
                self._write_status("running")

            except KalshiAPIError as exc:
                logger.error("API error during cycle: %s", exc)
                self._write_status("error", str(exc))
                time.sleep(30)
            except Exception as exc:
                logger.exception("Unexpected error during cycle: %s", exc)
                self._write_status("error", str(exc))
                time.sleep(60)

        self._shutdown()

    def _run_cycle(self) -> None:
        """Single trading cycle with multi-signal execution."""
        if not self.behavior.state.is_active:
            if self.behavior.should_start_session():
                self.behavior.start_session()
            else:
                # Refresh balance even during idle so the dashboard never shows $0
                try:
                    self._refresh_state()
                except Exception:
                    pass
                self.behavior.idle_wait()
                return

        if self.behavior.should_end_session():
            self._end_of_session()
            self.behavior.end_session()
            self.behavior.idle_wait()
            return

        self._refresh_state()

        if not self.risk.can_trade():
            logger.info("Risk manager says NO. Waiting.")
            self.behavior.long_pause()
            return

        self.behavior.wait()

        # Clear external signal cache for new scan cycle
        self.external_signals.clear_cache()

        opportunities = self.scanner.scan()
        if not opportunities:
            logger.info("No opportunities found this scan.")
            self.behavior.wait()
            return

        # Filter to specialist categories
        specialist_opps = [
            opp for opp in opportunities
            if self._matches_specialist({
                "ticker": opp.ticker,
                "category": opp.category,
                "title": opp.title,
            })
        ]

        if not specialist_opps:
            logger.info("No specialist-matched opportunities for %s.", self.bot_name)
            self.behavior.wait()
            return

        logger.info(
            "%d specialist opportunities (from %d total).",
            len(specialist_opps), len(opportunities),
        )

        if self.behavior.should_browse_only():
            import random
            browse_target = random.choice(specialist_opps)
            self.scanner.enrich(browse_target)
            logger.info("Browsed %s without trading.", browse_target.ticker)
            self.behavior.record_action(traded=False)
            self.behavior.wait()
            return

        # Enrich top-N
        top_n = min(10, len(specialist_opps))
        for opp in specialist_opps[:top_n]:
            self.scanner.enrich(opp)
            self.behavior.wait()

        signals = self.analysis.analyse(specialist_opps[:top_n])
        if not signals:
            logger.info("No signals above confidence threshold.")
            self.behavior.record_action(traded=False)
            self.behavior.wait()
            return

        # --- Multi-signal execution ---
        # Execute all qualifying signals up to the risk manager's open position cap.
        # Each trade is checked individually against can_trade() to respect
        # daily limits, drawdown, and position count guards.
        max_signals_per_cycle = self.cfg.get("trading", {}).get("max_signals_per_cycle", 3)
        trades_executed = 0

        for signal in signals[:max_signals_per_cycle]:
            if not self.risk.can_trade():
                logger.info("Risk manager halted further trades this cycle.")
                break
            # Skip if another bot already claimed this ticker
            # (conflict resolver is checked inside _execute_trade)
            self._execute_trade(signal)
            trades_executed += 1
            if trades_executed < len(signals[:max_signals_per_cycle]):
                self.behavior.wait()  # human-like gap between orders

        if trades_executed == 0:
            self.behavior.record_action(traded=False)

        self._reconcile_outcomes()

        if self.learning.should_review():
            new_weights = self.learning.review_and_recalibrate(self.analysis.weights)
            self.analysis.update_weights(new_weights)
            trend = self.learning.trend
            logger.info(
                "Trend after review: WR_delta=%.1f%% mult=%.2f hot=%s cold=%s",
                trend.win_rate_trend * 100,
                trend.momentum_multiplier,
                trend.hot_categories,
                trend.cold_categories,
            )
    def _execute_trade(self, signal) -> None:
        """Execute a trade -- mirrors agent.py logic."""
        base_count = self.risk.position_size(signal.confidence, signal.suggested_price)
        trend_mult = self.learning.trend.momentum_multiplier
        base_count = max(1, int(base_count * trend_mult))
        count = self.behavior.vary_trade_size(base_count)

        logger.info(
            "Executing: %s %s on %s | conf=%.1f | price=%d | count=%d",
            signal.action, signal.side, signal.ticker,
            signal.confidence, signal.suggested_price, count,
        )

        self.behavior.order_jitter()

        try:
            order_type = self.cfg.get("trading", {}).get("default_order_type", "limit")
            price_kwarg = {}
            if signal.side == "yes":
                price_kwarg["yes_price"] = signal.suggested_price
            else:
                price_kwarg["no_price"] = signal.suggested_price

            result = self.client.create_order(
                ticker=signal.ticker,
                side=signal.side,
                action=signal.action,
                count=count,
                order_type=order_type,
                **price_kwarg,
            )

            order = result.get("order", result)
            order_id = order.get("order_id", "unknown")
            logger.info("Order placed: id=%s", order_id)

            db_id = self.learning.log_trade(
                ticker=signal.ticker,
                event_ticker=signal.event_ticker,
                title=signal.title,
                side=signal.side,
                action=signal.action,
                count=count,
                entry_price=signal.suggested_price,
                confidence=signal.confidence,
                edge_score=signal.edge_score,
                liquidity_score=signal.liquidity_score,
                volume_score=signal.volume_score,
                timing_score=signal.timing_score,
                momentum_score=signal.momentum_score,
                rationale=signal.rationale,
                series_ticker=signal.ticker.split("-")[0] if "-" in signal.ticker else signal.ticker,
                category=signal.category,
            )
            self._pending_trades[signal.ticker] = db_id
            self._trade_count += 1
            self.behavior.record_action(traded=True)

        except KalshiAPIError as exc:
            logger.error("Order failed for %s: %s", signal.ticker, exc)
            self.behavior.record_action(traded=False)

    def _reconcile_outcomes(self) -> None:
        """
        Check for settled trades and update outcomes.

        v4 improvements:
        - Also checks positions directly for unrealized P&L on stale pending trades
          (trades open > stale_hours are force-resolved using current position data).
        - Triggers sell/exit orders for positions with significantly negative edge
          that have not yet settled naturally.
        """
        if not self._pending_trades:
            # Still check for stale DB entries (e.g. from a previous run)
            stale = self.learning.get_stale_pending_trades(
                min_age_hours=self.cfg.get("trading", {}).get("stale_trade_hours", 48.0)
            )
            for trade in stale:
                logger.warning(
                    "Found stale pending trade id=%d ticker=%s from %s. Force-resolving.",
                    trade["id"], trade["ticker"], trade["timestamp"],
                )
                self._force_resolve_trade(trade["id"], trade["ticker"], trade.get("count", 1))
            return

        try:
            positions = self.client.get_positions()
            pos_by_ticker = {p["ticker"]: p for p in positions}
            settlements = self.client.get_settlements()
            settled_tickers = {s.get("ticker") or s.get("market_ticker") for s in settlements}

            resolved = []
            stale_age_hours = self.cfg.get("trading", {}).get("stale_trade_hours", 48.0)
            exit_threshold_cents = self.cfg.get("trading", {}).get("exit_loss_threshold_cents", -20)

            for ticker, db_id in list(self._pending_trades.items()):
                # --- Case 1: Market has settled ---
                if ticker in settled_tickers:
                    pos = pos_by_ticker.get(ticker, {})
                    pnl = pos.get("realized_pnl", 0)
                    outcome = "win" if pnl >= 0 else "loss"
                    self.learning.update_outcome(db_id, outcome, pnl_cents=pnl)
                    self.risk.record_outcome(pnl)
                    resolved.append(ticker)
                    logger.info("Resolved %s: %s (%+d cents)", ticker, outcome, pnl)
                    continue

                # --- Case 2: Position exists but not settled yet ---
                pos = pos_by_ticker.get(ticker)
                if pos is not None:
                    unrealized = pos.get("unrealized_pnl", 0)
                    position_qty = pos.get("position", 0)

                    # Exit if unrealized loss exceeds threshold
                    if unrealized <= exit_threshold_cents and position_qty > 0:
                        logger.info(
                            "Exit signal for %s: unrealized P&L %+d¢ below threshold %+d¢. "
                            "Placing sell order.",
                            ticker, unrealized, exit_threshold_cents,
                        )
                        self._place_exit_order(ticker, pos)

                # --- Case 3: Stale — trade logged but no position found and not settled ---
                from datetime import datetime, timezone
                import sqlite3
                trade_rows = self._conn_get_trade_ts(db_id)
                if trade_rows:
                    trade_ts_str = trade_rows
                    try:
                        trade_ts = datetime.fromisoformat(trade_ts_str)
                        age_hours = (datetime.now(timezone.utc) - trade_ts).total_seconds() / 3600.0
                        if age_hours > stale_age_hours:
                            logger.warning(
                                "Stale pending trade id=%d ticker=%s (%.1fh old). Force-resolving.",
                                db_id, ticker, age_hours,
                            )
                            self._force_resolve_trade(db_id, ticker, pos.get("position", 1) if pos else 1)
                            resolved.append(ticker)
                    except Exception:
                        pass

            for t in resolved:
                del self._pending_trades[t]

        except Exception as exc:
            logger.warning("Reconciliation error: %s", exc)

    def _conn_get_trade_ts(self, trade_id: int) -> Optional[str]:
        """Helper: fetch timestamp for a trade by ID from the learning DB."""
        try:
            rows = self.learning._conn.execute(
                "SELECT timestamp FROM trades WHERE id = ?", (trade_id,)
            ).fetchone()
            return rows[0] if rows else None
        except Exception:
            return None

    def _force_resolve_trade(self, db_id: int, ticker: str, count: int) -> None:
        """
        Force-resolve a trade that is past its staleness threshold.
        Uses fill history to find the actual outcome; falls back to neutral.
        """
        try:
            fills = self.client.get_fills()
            fill_pnl = 0
            found = False
            for fill in fills:
                if fill.get("ticker") == ticker:
                    fill_pnl += fill.get("profit_loss", 0)
                    found = True

            if found:
                outcome = "win" if fill_pnl >= 0 else "loss"
                self.learning.update_outcome(db_id, outcome, pnl_cents=fill_pnl)
                self.risk.record_outcome(fill_pnl)
                logger.info("Force-resolved %s via fills: %s (%+d¢)", ticker, outcome, fill_pnl)
            else:
                # No fills found — mark as expired/neutral
                self.learning.update_outcome(db_id, "expired", pnl_cents=0)
                logger.info("Force-resolved %s as expired (no fills found).", ticker)
        except Exception as exc:
            logger.warning("Force-resolve failed for %s: %s", ticker, exc)

    def _place_exit_order(self, ticker: str, position: Dict[str, Any]) -> None:
        """
        Place a market sell order to exit a position with deteriorating edge.

        Kalshi doesn't support traditional stop-losses, so we sell our
        existing contracts at market price.
        """
        try:
            qty = abs(int(position.get("position", 0)))
            if qty == 0:
                return

            # Determine which side we hold
            side = position.get("side", "yes")

            result = self.client.create_order(
                ticker=ticker,
                side=side,
                action="sell",
                count=qty,
                order_type="market",
            )
            order = result.get("order", result)
            logger.info(
                "Exit order placed for %s: sell %d x %s | order_id=%s",
                ticker, qty, side, order.get("order_id", "unknown"),
            )
        except Exception as exc:
            logger.warning("Failed to place exit order for %s: %s", ticker, exc)

    def _refresh_state(self) -> None:
        """Refresh balance and position state."""
        try:
            logger.info(f"[{self.bot_name}] Fetching balance...")
            balance_data = self.client.get_balance()
            balance = balance_data.get("balance", 0)
            logger.info(f"[{self.bot_name}] Balance received: {balance}¢")
            
            # FIX: Only update if we got a valid balance, otherwise preserve last known
            if balance > 0:
                self._last_known_balance = balance
                self._last_balance_update = datetime.now(timezone.utc)
                self.risk.update_balance(balance)
            elif self._last_known_balance > 0:
                # API returned 0 but we have cached value - use cache
                logger.warning(f"[{self.bot_name}] API returned 0 balance, using cached {self._last_known_balance}¢")
                self.risk.update_balance(self._last_known_balance)
            else:
                # First run and API returned 0, update anyway
                self.risk.update_balance(balance)
                
        except KalshiAPIError as exc:
            logger.error(f"[{self.bot_name}] Failed to fetch balance: {exc}")
            # FIX: On API error, preserve last known balance
            if self._last_known_balance > 0:
                logger.info(f"[{self.bot_name}] Using cached balance {self._last_known_balance}¢")
                self.risk.update_balance(self._last_known_balance)
        except Exception as exc:
            logger.error(f"[{self.bot_name}] Unexpected error fetching balance: {exc}")
            # FIX: On any error, preserve last known balance
            if self._last_known_balance > 0:
                logger.info(f"[{self.bot_name}] Using cached balance {self._last_known_balance}¢")
                self.risk.update_balance(self._last_known_balance)

        try:
            positions = self.client.get_positions(count_filter="position")
            self.risk.update_open_positions(len(positions))
        except KalshiAPIError as exc:
            logger.warning("Failed to fetch positions: %s", exc)

    def _end_of_session(self) -> None:
        """End-of-session tasks."""
        status = self.risk.status()
        perf = self.learning.get_performance(
            last_n=self.learning.cfg.get("rolling_window", 50)
        )
        self.learning.save_daily_summary(
            pnl_cents=status["daily_pnl_cents"],
            trades=status["trades_today"],
            wins=status["wins_today"],
            losses=status["losses_today"],
            avg_conf=perf.get("avg_confidence", 0),
        )

    def _shutdown(self) -> None:
        """Graceful shutdown."""
        logger.info("Shutting down bot '%s'.", self.bot_name)
        self._end_of_session()
        self.learning.close()
        self._write_status("stopped")
        logger.info("Bot '%s' stopped.", self.bot_name)

    # ------------------------------------------------------------------
    # Status reporting
    # ------------------------------------------------------------------

    def _write_status(self, state: str, error: str = "") -> None:
        """Write status to a JSON file for the coordinator to read."""
        try:
            perf = self.learning.get_performance()
            risk_status = self.risk.status()
            
            # FIX: Ensure balance is never 0 in status if we have a cached value
            if risk_status.get("balance_cents", 0) == 0 and self._last_known_balance > 0:
                risk_status["balance_cents"] = self._last_known_balance
                risk_status["last_known_balance"] = True

            status = {
                "bot_name": self.bot_name,
                "display_name": self.cfg.get("bot", {}).get("display_name", self.bot_name),
                "specialist": self.cfg.get("bot", {}).get("specialist", "general"),
                "state": state,
                "error": error,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "session_start": self._session_start.isoformat() if self._session_start else None,
                "trade_count": self._trade_count,
                "pending_trades": len(self._pending_trades),
                "performance": perf,
                "risk": risk_status,
                "pid": os.getpid(),
            }

            # FIX: Use atomic write to prevent corruption
            temp_file = self._status_file.with_suffix('.tmp')
            with open(temp_file, "w") as fh:
                json.dump(status, fh, indent=2)
            temp_file.replace(self._status_file)

        except Exception as exc:
            logger.debug("Failed to write status file: %s", exc)

    # ------------------------------------------------------------------
    # External control
    # ------------------------------------------------------------------

    def pause(self) -> None:
        """Pause the bot (stop trading but keep running)."""
        self._paused = True
        logger.info("Bot '%s' paused.", self.bot_name)

    def resume(self) -> None:
        """Resume trading."""
        self._paused = False
        logger.info("Bot '%s' resumed.", self.bot_name)

    def stop(self) -> None:
        """Stop the bot."""
        self._running = False


# ------------------------------------------------------------------
# CLI entry point
# ------------------------------------------------------------------

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Kalshi Bot Runner")
    parser.add_argument("--bot-name", required=True, help="Bot identifier")
    parser.add_argument(
        "--swarm-config",
        default="config/swarm_config.yaml",
        help="Path to swarm config",
    )
    parser.add_argument(
        "--bot-config",
        required=True,
        help="Path to bot-specific config",
    )
    parser.add_argument(
        "--project-root",
        default=".",
        help="Project root directory",
    )
    args = parser.parse_args()

    runner = BotRunner(
        bot_name=args.bot_name,
        swarm_config_path=args.swarm_config,
        bot_config_path=args.bot_config,
        project_root=args.project_root,
    )
    runner.run()


if __name__ == "__main__":
    main()
